﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.Primary_Forms
{
    public partial class AjustarStockForm : Form
    {
        public AjustarStockForm()
        {
            InitializeComponent();
        }
    }
}
