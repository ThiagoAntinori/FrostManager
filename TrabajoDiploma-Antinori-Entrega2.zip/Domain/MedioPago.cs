﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain
{
    public enum MedioPago
    {
        Efectivo = 1,
        Transferencia,
        Tarjeta,
        NoAsignado
    }
}
